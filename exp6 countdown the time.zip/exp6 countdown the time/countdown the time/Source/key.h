#ifndef _KEY_
#define _KEY_
#include "mcu.h"
extern	uint8_t	skeychat;											
extern uint8_t alarm, setup, keycvtbuf2;
extern void Mnkey(void);
extern	void Wr_FIFO(void);
extern uint8_t alarm_data[3];
#endif