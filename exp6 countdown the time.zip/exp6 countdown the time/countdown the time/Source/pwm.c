#include "mcu.h"
#include "pwm.h"

code uint16_t musical_tab = 65369;

uint16_t t2_load_value;
uint16_t buzzer_cnt = 0;

void buzzer_pwm_config()
{
  buzzer_fre_set();
  T2CON = 0x41; //fcpu 12=> T= 1.5 us

  CCEN = 0X02;
  
  TH2 = t2_load_value>>8;
  TL2 = t2_load_value;
  ET2 = 1;
}

void buzzer_beep_ms(uint16_t ms)
{
	buzzer_cnt = ms*4; 
	buzzer_pwm_config();
}

void T2COM0Interrupt(void) interrupt ISRTimer2 
{
  TH2 = t2_load_value>>8;
  TL2 = t2_load_value;
  TF2 = 0;
	//CRCH/CRCL- TH2/TL2 =667 ticks * 1.5us = 1 ms
	if (buzzer_cnt > 0){
			buzzer_cnt--;
			if (buzzer_cnt == 0)
			{
					CCEN &= ~0x02; //tat buzzer
			}
	}
}

void buzzer_fre_set()
{

  t2_load_value = musical_tab;
  CRCH =(t2_load_value +(65536-t2_load_value)/2) >> 8;
  CRCL =(t2_load_value +(65536-t2_load_value)/2);
}