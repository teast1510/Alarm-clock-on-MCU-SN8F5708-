#ifndef _MCU_
#define _MCU_
#include "sn8f5708.h"
#endif