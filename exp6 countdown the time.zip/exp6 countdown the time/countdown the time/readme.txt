/*

Use T0 to generate 1MS timing, add up to 1S, and add one to the count displayed on the digital tube

*/